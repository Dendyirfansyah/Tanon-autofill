<?php
  $project_location = "/tanon-form";
  $me = $project_location;

  $request = $_SERVER['REQUEST_URI'];

  switch ($request) {
    case $me.'/login' :
      require "views/login.php";
      break;
    case $me.'/loginproses' :
      require "controller/login.php";
      break;
    case $me.'/home' :
      require "views/home.php";
      break;

    case $me.'/f102' :
      require "controller/f102.php";
      break;
    case $me.'/f103' :
      require "controller/f103.php";
      break;
    case $me.'/f104' :
      require "controller/f104.php";
      break;
    case $me.'/f106' :
      require "controller/f106.php";
      break;

    default:
      require "views/login.php";
      break;
  }
?>